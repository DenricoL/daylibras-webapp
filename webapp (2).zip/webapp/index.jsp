<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
    
<!DOCTYPE html>
<html>
    <head>
        <title> DayLibras </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale = 1.0">

        <link rel="stylesheet" href="css/index.css">
        <script src="js/main.js"></script>
    </head>

    <body>
		<div class="containerheader">
		<header>
			<div class="menu">
				<img src="img/menu.png" width="40px">
			</div>
			<a href="index.jsp"> <img src="img/logo.png"> </a>
			<div class="moon">
				<img src="img/darkmode.png" width="40px" onclick="toggleDarkMode()">
			</div>
		</header>
		</div>
		
        <div class="container">
                
            <div class="box">
                <div id="board">
                </div>
            </div>
            	
            <div class="box">
                <img id="gif" width="300px" alt="Gif do Dia">
            </div>
            
        </div>

        <br>
        <h1 id="answer"></h1>
    </body>
    
    
    
<script>
// =================== modo escuro ===================

function toggleDarkMode() {
    document.body.classList.toggle("dark");

    // Salva a preferência no localStorage
    if (document.body.classList.contains("dark")) {
        localStorage.setItem('theme', 'dark');
    } else {
        localStorage.setItem('theme', 'light');
    }


    // Troca ícone do modo (lua/sol) [cite: 4]
    const moonImg = document.querySelector('.moon img');
    moonImg.src = document.body.classList.contains("dark")
        ? "img/lightmode.png"
        : "img/darkmode.png";

    // Troca cor da logo `DayLibras` (claro/escuro) [cite: 5]
    const logoImg = document.querySelector('header img[src*="logo"]');
    if (logoImg) {
        logoImg.src = document.body.classList.contains("dark")
          ? [cite_start]"img/darklogo.png" [cite: 6]
          : "img/logo.png";
    }

    // Troca cor do menu hamburguer (claro/escuro)
    const menuImg = document.querySelector('.menu img');
    if (menuImg) {
        menuImg.src = document.body.classList.contains("dark")
          ? "img/darkmenu.png"
          : "img/menu.png";
    }

    [cite_start]// Troca cor do login (claro/escuro) [cite: 8]
    const loginImg = document.querySelector('.box img[src*="login"]');
    if (loginImg) {
        loginImg.src = document.body.classList.contains("dark")
          ? [cite_start]"img/darklogin.png" [cite: 9]
          : "img/login.png";
    }

    // sound effect ao clicar no toggle
    const audioSrc = document.body.classList.contains("dark")
        ? "audio/bubble-popLua.mp3"
        : "audio/bubble-popSol.mp3";
    [cite_start]const audio = new Audio(audioSrc); [cite: 10]
    audio.play();
}	
</script>
    
    
</html>
