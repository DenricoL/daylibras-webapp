<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fn" uri="jakarta.tags.functions"%>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title> Perfil </title>
		
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/profile.css">
	</head>
	
	<body>
		<!-- inicio header -->
		<div class="containerheader">
			<header>
				<div class="menu">
					<img src="img/menu.png" width="40px">
				</div>
				<a href="index.jsp"> <img src="img/logo.png">
				</a>
				<div class="moon">
					<img src="img/darkmode.png" width="40px" onclick="toggleDarkMode()">
				</div>
			</header>
		</div>

		<div id="sidebar" class="sidebar">
			<div class="items">
			<a href="javascript:void(0)" class="closebtn">x</a>
			<a href="loginUser.jsp">Login</a>
			<a href="#">Tutorial</a>
			<a href="#">Modo Livre</a>
			<a href="#">Sobre</a>
			</div>
		</div>
		<!-- fim header -->
		
		<!-- inicio main -->
		<div class="box-container">
			<div class="box">
				<div class="picture">
					<img src="img/profile/picture.png">
				</div>
				
				<div class="username">
					<h1 class="text"> ${sessionScope.user.nome} </h1>
					<h2 class="text"> Registrado desde [data] </h2>
				</div>
			</div>
			
			<div class="box">
				<div class="statistics">
					<div class="top">
						<p class="text"> Total de Acertos: <br> X </p>
						<p class="text"> Acertos Perfeitos: <br> X </p>
					</div>
					
					<div class="down">
						<p class="text"> Maior Sequência de Acertos: <br> X dias </p>
					</div>
				</div>
				
				<div class="level">
					<div class="text">
						<p class="text"> Nível </p>
					</div>
					
					<div class="number">
						<p class="text"> 5 </p>
					</div>
				</div>
			</div>
		</div>
		
		<div class="buttons-container">
			<a href="#"> Mais detalhes </a>
			<a href="#"> Editar </a>
		</div>
		<!-- fim main -->
		
		<script>
			// ================================= barra de navegação ==================================
			const menuButton = document.querySelector('.menu');
			const closeButton = document.querySelector('.closebtn');
			const sidebar = document.getElementById('sidebar');
	
			menuButton.addEventListener('click', () => {
				sidebar.style.width = '250px';
			});
	
			closeButton.addEventListener('click', () => {
				sidebar.style.width = '0';
			});

			// ====================================== modo escuro ======================================
			function toggleDarkMode() {
				document.body.classList.toggle("dark");
	
				// Troca Ã­cone do modo (lua/sol)
				const moonImg = document.querySelector('.moon img');
				moonImg.src = document.body.classList.contains("dark") ? "img/lightmode.png"
						: "img/darkmode.png";
	
				// Troca cor da logo `DayLibras` (claro/escuro)
				const logoImg = document.querySelector('header img[src*="logo"]');
				if (logoImg) {
					logoImg.src = document.body.classList.contains("dark") ? "img/darklogo.png"
							: "img/logo.png";
				}
	
				// Troca cor do menu hamburguer (claro/escuro)
				const menuImg = document.querySelector('.menu img');
				if (menuImg) {
					menuImg.src = document.body.classList.contains("dark") ? "img/darkmenu.png"
							: "img/menu.png";
				}
	
				// Troca cor do login (claro/escuro)
				const loginImg = document.querySelector('.box img[src*="login"]');
				if (loginImg) {
					loginImg.src = document.body.classList.contains("dark") ? "img/darklogin.png"
							: "img/login.png";
				}
	
				// sound effect ao clicar no toggle
				const audioSrc = document.body.classList.contains("dark") ? "audio/bubble-popLua.mp3"
						: "audio/bubble-popSol.mp3";
				const audio = new Audio(audioSrc);
				audio.play();
			}
		</script>
	</body>
</html>

