<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>DayLibras - Login</title>
<link rel="stylesheet" href="css/redirect.css">

</head>
<body>
	<div class="container">

		<div class="box">
            <img src="img/em-construcao.png" width="70px">
			<br>
            Esta página está em construção. Em breve estará disponível!
            <br>
            <button class="btn-cadastro" onclick="location.href='index.jsp'">Voltar ao DayLibras</button>
			</form>

		</div>
	</div>


</body>
</html>
