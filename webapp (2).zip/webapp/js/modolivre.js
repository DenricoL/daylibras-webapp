/* Script do Jogo */

var height = 6; // número de tentativas
var width = 5;  // tamanho da palavra

var row = 0; // tentativa atual
var col = 0; // letra atual dentro da tentativa

var gameOver = false;  // saber se jogo acabou
var playerWin = false; // saber se o player ganhou
var guessArr = [];     // impedir player repetir tentativa
var wordList = ["comer", "nadar", "aviao", "porta", "pular", "prato", "serra", "gaita", "peixe", "bolsa", "garfo", "piano", "chave"];

function removeAccentsAndLowercase(list) {
    return list.map(word => 
        word
            .toLowerCase()
            .normalize("NFD")                // decompõe os caracteres acentuados ('é' = 'e' + '´')
            .replace(/[\u0300-\u036f]/g, '') // remove os acentos
    );
}

// lista de palavras que podem ser usadas como tentativa
dictionary = ["Aarão", "Abner", "Acaia", "Acker", "Aires", "Alair", "Alceu", "Algol", "Aline", "Alpes", "Amapá", "André", "Argel", "Argos", "Artur", "Aécio", "Babel", "Bagdá", "Bangu", "Belém", "Bento", "Berna", "Berta", "Bielo", "Borba", "Bruno", "Carla", "Ceará", "Chica", "Chico", "Chile", "China", "Couto", "Cátia", "César", "Dafne", "Darci", "Dario", "David", "Denis", "Diana", "Dácia", "Edgar", "Edite", "Egito", "Elias", "Elisa", "Elixa", "Emaús", "Esopo", "Ester", "Euler", "Filho", "Fábio", "Gales", "Gauss", "Goiás", "Golfo", "Hegel", "Intel", "Jaime", "Japão", "Jesus", "Jobim", "Jorge", "Kazuo", "Kioto", "Klein", "Labma", "Lages", "Laura", "Lauro", "Lenin", "Linda", "Linus", "Linux", "Lúcio", "Malba", "Marco", "Maria", "Marta", "Marte", "Mauro", "Miami", "Minas", "Morse", "Mário", "Média", "Natal", "Neusa", "Nobel", "Norte", "Paris", "Paula", "Paulo", "Peano", "Pedro", "Piauí", "Porto", "Praga", "Ramos", "Romeu", "Rouen", "Saara", "Santa", "Santo", "Silva", "Souza", "Suíça", "Síria", "Sônia", "Terra", "Texas", "Tomás", "União", "VARIG", "Vegas", "Verbo", "Viena", "Vista", "Vênus", "abade", "abafa", "abafe", "abafo", "abafá", "abala", "abale", "abalo", "abalá", "abana", "abane", "abano", "abaná", "abata", "abate", "abati", "abato", "abatê", "abeto", "ablua", "ablui", "abluo", "abluí", "abole", "aboli", "abono", "abram", "abras", "abrem", "abres", "abreu", "abria", "abril", "abrir", "abris", "abriu", "abstê", "abusa", "abuse", "abuso", "abusá", "acaba", "acabe", "acabo", "acabá", "acaso", "acata", "acate", "acato", "acatá", "acena", "acene", "aceno", "acená", "acesa", "aceso", "aceto", "achai", "acham", "achar", "achas", "achei", "achem", "aches", "achou", "acima", "acode", "acolá", "acuai", "acuam", "acuar", "acuas", "acuda", "acudi", "acudo", "acuei", "acuem", "acues", "acuou", "acusa", "acuse", "acuso", "acusá", "adaga", "adega", "adere", "aderi", "adeus", "adiai", "adiam", "adiar", "adias", "adida", "adido", "adiei", "adiem", "adies", "adimo", "adiou", "adira", "adiro", "adirá", "adita", "adite", "adito", "aditá", "adoce", "adora", "adore", "adoro", "adorá", "adota", "adote", "adoto", "adotá", "adoça", "adoço", "adoçá", "aduba", "adube", "adubo", "adubá", "adula", "adule", "adulo", "adulá", "advim", "advir", "advém", "afaga", "afago", "afagá", "afana", "afane", "afano", "afaná", "afegã", "afere", "aferi", "afeta", "afete", "afeto", "afetá", "afiai", "afiam", "afiar", "afias", "afiei", "afiem", "afies", "afina", "afine", "afino", "afins", "afiná", "afiou", "afira", "afiro", "afixa", "afixe", "afixo", "afixá", "aflua", "aflui", "afluo", "afluí", "afoba", "afobe", "afobo", "afobá", "afofa", "afofe", "afofo", "afofá", "afoga", "afogo", "afogá", "afora", "afore", "aforo", "aforá", "afros", "aftas", "agiam", "agias", "agido", "agimo", "agira", "agirá", "agita", "agite", "agito", "agitá", "agora", "aguai", "aguam", "aguar", "aguas", "aguce", "aguda", "agudo", "aguei", "aguem", "agues", "aguou", "aguça", "aguço", "aguçá", "ainda", "aires", "ajais", "ajamo", "ajuda", "ajude", "ajudo", "ajudá", "alada", "alado", "alaga", "alago", "alagá", "alcei", "alcem", "alces", "aldeã", "alega", "alego", "alegá", "alemã", "algas", "algoz", "algum", "alheá", "alhos", "aliai", "aliam", "aliar", "alias", "aliei", "aliem", "alies", "alija", "alije", "alijo", "alijá", "aliou", "alisa", "alise", "aliso", "alisá", "aliás", "almas", "aloca", "aloco", "alocá", "aloja", "aloje", "alojo", "alojá", "aloés", "altar", "altas", "alteá", "altos", "aluda", "alude", "aludi", "aludo", "aluga", "alugo", "alugá", "aluna", "aluno", "alvas", "alves", "alvor", "alvos", "alçai", "alçam", "alçar", "alças", "alçou", "amada", "amado", "amais", "amamo", "amara", "amaro", "amará", "amava", "ambas", "ambos", "ameba", "ameia", "ameis", "amemo", "amena", "ameno", "ameça", "amido", "amiga", "amigo", "amigá", "amima", "amime", "amimo", "amimá", "amola", "amole", "amolo", "amolá", "amora", "ampla", "amplo", "anais", "ancas", "anciã", "andai", "andam", "andar", "andas", "andei", "andem", "andes", "andor", "andou", "andré", "anela", "anele", "anelo", "anelá", "anexa", "anexe", "anexo", "anexá", "anglo", "angra", "anima", "anime", "animo", "animá", "anjos", "anota", "anote", "anoto", "anotá", "ansiá", "antas", "antes", "antro", "antão", "anual", "anuam", "anuas", "anuem", "anuir", "anuis", "anuiu", "anula", "anule", "anulo", "anulá", "anuía", "anuís", "anzol", "anéis", "anões", "aonde", "aorta", "apaga", "apago", "apagá", "apara", "apare", "aparo", "apará", "apeai", "apear", "apeei", "apega", "apego", "apegá", "apeia", "apeie", "apeio", "apela", "apele", "apelo", "apelá", "apena", "apene", "apeno", "apená", "apeou", "apita", "apite", "apito", "apitá", "apoio", "apoiá", "apolo", "aptas", "aptos", "apura", "apure", "apuro", "apurá", "apóia", "apóie", "apóio", "aquém", "arada", "arado", "arais", "arame", "aramo", "arara", "arará", "arava", "araçá", "arcai", "arcam", "arcar", "arcas", "arcos", "arcou", "ardam", "ardas", "ardei", "ardem", "arder", "ardes", "ardeu", "ardia", "ardil", "ardis", "ardor", "areal", "areia", "areis", "areja", "areje", "arejo", "arejá", "aremo", "arena", "arfai", "arfam", "arfar", "arfas", "arfei", "arfem", "arfes", "arfou", "argua", "arguo", "arguí", "argúi", "argui", "armai", "armam", "armar", "armas", "armei", "armem", "armes", "armou", "aroma", "arpoa", "arpoe", "arpoá", "arpão", "arpôo", "arque", "arreá", "arria", "arrie", "arrio", "arriá", "arroz", "artes", "artur", "asila", "asile", "asilo", "asilá", "asnos", "aspas", "assai", "assam", "assar", "assas", "assaz", "assei", "assem", "asses", "asseá", "assim", "assis", "assoa", "assoe", "assou", "assoá", "assôo", "astro", "ataca", "ataco", "atacá", "atada", "atado", "atais", "atamo", "atara", "atará", "atava", "ateai", "atear", "ateei", "ateia", "ateie", "ateio", "ateis", "atemo", "ateou", "aterá", "ateus", "ateve", "atice", "atido", "atina", "atine", "atino", "atiná", "atira", "atire", "atiro", "atirá", "ativa", "ative", "ativo", "ativá", "atiça", "atiço", "atiçá", "atlas", "atola", "atole", "atolo", "atolá", "atrai", "atraí", "atriz", "atrás", "atuai", "atual", "atuam", "atuar", "atuas", "atuei", "atuem", "atues", "atuns", "atuou", "atura", "ature", "aturo", "aturá", "atéia", "aténs", "audaz", "aulas", "auras", "autor", "autos", "autua", "autue", "autuo", "autuá", "avais", "avara", "avaro", "aveia", "aveio", "avelã", "aviai", "aviam", "aviar", "avias", "aviei", "aviem", "avier", "avies", "avimo", "aviou", "avirá", "avisa", "avise", "aviso", "avisá", "aviva", "avive", "avivo", "avivá", "avião", "avéns", "axial", "axila", "azara", "azare", "azaro", "azará", "azeda", "azede", "azedo", "azedá", "azias", "azoto", "azuis", "azula", "azule", "azulo", "azulá", "açude", "ações", "aérea", "aéreo", "babai", "babam", "babar", "babas", "babei", "babem", "babes", "babou", "babás", "babão", "bacia", "bafos", "bagas", "bagos", "bahia", "baias", "baila", "baile", "bailo", "bailá", "baita", "baixa", "baixe", "baixo", "baixá", "baião", "balam", "balas", "balde", "balem", "bales", "baleá", "balia", "balir", "balis", "baliu", "balsa", "balão", "bamba", "bambo", "bambu", "banal", "banca", "banco", "bancá", "banda", "bando", "banem", "banes", "banha", "banhe", "banho", "banhá", "bania", "banir", "banis", "baniu", "banjo", "baque", "barba", "barca", "barco", "bardo", "bares", "barra", "barre", "barro", "barrá", "barão", "bases", "baseá", "basta", "baste", "basto", "bastá", "batam", "batas", "batei", "batel", "batem", "bater", "bates", "bateu", "batia", "batom", "bauru", "bazar", "baços", "baías", "beata", "beato", "bebam", "bebas", "bebei", "bebem", "beber", "bebes", "bebeu", "bebia", "bebês", "becas", "becos", "beija", "beije", "beijo", "beijá", "beira", "beire", "beiro", "beirá", "beiço", "belas", "belga", "belos", "bemol", "benta", "bento", "benza", "benze", "benzi", "benzo", "benzê", "beque", "berna", "berra", "berre", "berro", "berrá", "berço", "besta", "bicai", "bicam", "bicar", "bicas", "bicha", "bicho", "bicos", "bicou", "biela", "bigas", "bingo", "bique", "birra", "bispo", "bisão", "blefa", "blefe", "blefo", "blefá", "bloco", "blusa", "boate", "boato", "bobas", "bobeá", "bobos", "bocal", "bocas", "bocha", "bodas", "bodes", "boiai", "boiar", "boiei", "boina", "boiou", "bolai", "bolam", "bolar", "bolas", "boldo", "bolei", "bolem", "boles", "bolha", "bolos", "bolou", "bolsa", "bolso", "bolão", "bomba", "bonde", "bonés", "borda", "borde", "bordo", "bordá", "borra", "borre", "borro", "borrá", "bossa", "bosta", "botai", "botam", "botar", "botas", "botei", "botem", "botes", "botou", "botão", "boxeá", "braba", "brabo", "brada", "brade", "brado", "bradá", "braga", "brama", "brame", "brami", "bramo", "bramá", "brasa", "brava", "bravo", "braça", "braço", "breca", "breco", "brecá", "brejo", "bretã", "breve", "brevê", "brida", "briga", "brigo", "brigá", "brins", "brios", "brisa", "brita", "brito", "broas", "broca", "broco", "brocá", "bromo", "brota", "brote", "broto", "brotá", "bruma", "bruta", "bruto", "bruxa", "bruxo", "bucal", "bucha", "bucho", "bueno", "bufai", "bufam", "bufar", "bufas", "bufei", "bufem", "bufes", "bufou", "bufão", "bujão", "bulam", "bulas", "bulbo", "bules", "bulia", "bulir", "bulis", "buliu", "bumbo", "bunda", "bunde", "bundo", "bundá", "burgo", "burla", "burle", "burlo", "burlá", "burra", "burro", "busca", "busco", "buscá", "busto", "buxos", "bário", "bílis", "bóiam", "bóias", "bóiem", "bóies", "bôers", "bônus", "búzio", "cabei", "cabem", "caber", "cabes", "cabia", "cabos", "cabra", "cacas", "cacei", "cacem", "caces", "cacho", "cacos", "cacto", "cafés", "cagai", "cagam", "cagar", "cagas", "cagou", "cague", "caiai", "caiam", "caiar", "caias", "caiba", "caibo", "caido", "caiei", "caiem", "caies", "caiou", "cairo", "cairá", "caixa", "calai", "calam", "calar", "calas", "calca", "calce", "calco", "calcá", "calda", "caldo", "calei", "calem", "cales", "calha", "calhe", "calho", "calhá", "calma", "calmo", "calor", "calos", "calou", "calva", "calvo", "calça", "calço", "calçá", "camas", "campo", "canal", "canas", "canaã", "canga", "canja", "canoa", "canos", "cansa", "canse", "canso", "cansá", "canta", "cante", "canto", "cantá", "capai", "capam", "capar", "capas", "capaz", "capei", "capem", "capes", "capim", "capou", "capta", "capte", "capto", "captá", "caput", "capuz", "caras", "cardo", "carga", "cargo", "carmo", "carne", "caros", "carpa", "carpe", "carpi", "carro", "carta", "carão", "casai", "casal", "casam", "casar", "casas", "casca", "casco", "casei", "casem", "cases", "casos", "casou", "caspa", "cassa", "casse", "casso", "cassá", "casta", "casto", "catai", "catam", "catar", "catas", "catei", "catem", "cates", "catou", "catre", "cauda", "caule", "causa", "cause", "causo", "causá", "cauta", "cauto", "cavai", "cavam", "cavar", "cavas", "cavei", "cavem", "caves", "cavia", "cavie", "cavio", "caviá", "cavou", "caçai", "caçam", "caçar", "caças", "caçoa", "caçoe", "caçou", "caçoá", "cação", "caçôo", "caíam", "caías", "caída", "caído", "caímo", "caíra", "ceado", "ceais", "ceamo", "ceara", "ceará", "ceava", "cedam", "cedas", "cedei", "cedem", "ceder", "cedes", "cedeu", "cedia", "cedro", "ceeis", "ceemo", "cegai", "cegam", "cegar", "cegas", "cegos", "cegou", "cegue", "ceiam", "ceias", "ceiem", "ceies", "ceifa", "ceife", "ceifo", "ceifá", "celas", "celta", "cenas", "censo", "cento", "ceras", "cerca", "cerco", "cercá", "cerda", "cerne", "cerni", "cerol", "cerra", "cerre", "cerro", "cerrá", "certa", "certo", "cervo", "cessa", "cesse", "cesso", "cessá", "cesta", "cesto", "cetim", "cetro", "chaga", "chago", "chagá", "chale", "chalé", "chama", "chame", "chamo", "chamá", "chapa", "chata", "chato", "chave", "checa", "checo", "checá", "chefa", "chefe", "chega", "chego", "chegá", "cheia", "cheio", "chiai", "chiam", "chiar", "chias", "chica", "chico", "chiei", "chiem", "chies", "china", "chiou", "choca", "choco", "chocá", "chora", "chore", "choro", "chorá", "chova", "chove", "chovi", "chovo", "chovê", "choça", "chupa", "chupe", "chupo", "chupá", "chuta", "chute", "chuto", "chutá", "chuva", "ciclo", "cidra", "cifra", "cifre", "cifro", "cifrá", "cinco", "cinda", "cinde", "cindi", "cindo", "cinge", "cingi", "cinja", "cinjo", "cinta", "cinto", "cinza", "ciosa", "cioso", "cipós", "circo", "cisca", "cisco", "ciscá", "cisma", "cisme", "cismo", "cismá", "cisne", "cisão", "citai", "citam", "citar", "citas", "citei", "citem", "cites", "citou", "civil", "civis", "ciúme", "clama", "clame", "clamo", "clamá", "clara", "claro", "clava", "clero", "clima", "clips", "clone", "cloro", "clube", "coada", "coado", "coagi", "coais", "coaja", "coajo", "coamo", "coara", "coará", "coava", "coaxa", "coaxe", "coaxo", "coaxá", "cobra", "cobre", "cobri", "cobro", "cobrá", "cocal", "cocei", "cocem", "coces", "cocho", "cocos", "coege", "coeis", "coemo", "coesa", "coeso", "coeva", "coevo", "cofre", "coibi", "coice", "coifa", "coisa", "coito", "colai", "colam", "colar", "colas", "colei", "colem", "coles", "colha", "colhe", "colhi", "colho", "colhê", "colou", "comam", "comas", "comei", "comem", "comer", "comes", "comeu", "comia", "compô", "comum", "conde", "cones", "congá", "conta", "conte", "conto", "contá", "contê", "copas", "copia", "copie", "copio", "copiá", "copos", "corai", "coral", "coram", "corar", "coras", "corda", "corei", "corem", "cores", "corja", "corno", "coroa", "coroe", "coros", "corou", "coroá", "corpo", "corra", "corre", "corri", "corro", "corrê", "corta", "corte", "corto", "cortá", "corvo", "corça", "corôa", "corôo", "cosam", "cosas", "cosei", "cosem", "coser", "coses", "coseu", "cosia", "cosmo", "cospe", "costa", "cotai", "cotam", "cotar", "cotas", "cotei", "cotem", "cotes", "cotou", "coube", "couro", "couto", "couve", "covas", "coxas", "coxim", "coxos", "cozam", "cozas", "cozei", "cozem", "cozer", "cozes", "cozeu", "cozia", "coçai", "coçam", "coçar", "coças", "coçou", "coíba", "coíbe", "coíbo", "crava", "crave", "cravo", "cravá", "crede", "credo", "creia", "creio", "crema", "creme", "cremo", "cremá", "crera", "crerá", "criai", "criam", "criar", "crias", "crido", "criei", "criem", "cries", "crime", "crina", "criou", "crise", "criva", "crive", "crivo", "crivá", "croma", "crome", "cromo", "cromá", "cruas", "cruel", "cruza", "cruze", "cruzo", "cruzá", "crêem", "cubas", "cubos", "cubra", "cubro", "cucas", "cucos", "cueca", "cuias", "cuida", "cuide", "cuido", "cuidá", "cujas", "cujos", "cujus", "culpa", "culpe", "culpo", "culpá", "culta", "culto", "cumes", "cunha", "cunhe", "cunho", "cunhá", "cupim", "cupom", "curai", "curam", "curar", "curas", "curei", "curem", "cures", "curou", "cursa", "curse", "curso", "cursá", "curta", "curte", "curti", "curto", "curva", "curve", "curvo", "curvá", "cuspa", "cuspi", "cuspo", "custa", "custe", "custo", "custá", "cuíca", "cápua", "célia", "césar", "césio", "cílio", "círio", "cívil", "cólon", "cópia", "côdea", "cúria", "cútis", "dadas", "dados", "damas", "damos", "danai", "danam", "danar", "danas", "dance", "dando", "danei", "danem", "danes", "danos", "danou", "dante", "dança", "danço", "dançá", "daqui", "dardo", "darei", "darem", "dares", "daria", "darás", "darão", "datai", "datam", "datar", "datas", "datei", "datem", "dates", "datou", "davam", "davas", "decai", "decaí", "dedal", "dedos", "deduz", "dedão", "deita", "deite", "deito", "deitá", "deixa", "deixe", "deixo", "deixá", "delas", "deles", "delta", "demos", "demão", "densa", "denso", "dente", "depor", "depus", "depôs", "depõe", "deram", "deras", "derem", "deres", "dermo", "desce", "desci", "descê", "desde", "despe", "despi", "dessa", "desse", "desta", "deste", "desça", "desço", "deter", "detém", "deusa", "devam", "devas", "devei", "devem", "dever", "deves", "deveu", "devia", "diabo", "dicas", "dieta", "digam", "digas", "digna", "digne", "digno", "digná", "dilua", "dilui", "diluo", "diluí", "diodo", "dique", "direi", "diria", "dirás", "dirão", "disca", "disco", "discá", "dispô", "disse", "disso", "dista", "diste", "disto", "distá", "ditai", "ditam", "ditar", "ditas", "ditei", "ditem", "dites", "ditos", "ditou", "divas", "dizei", "dizem", "dizer", "dizes", "dizia", "doada", "doado", "doais", "doamo", "doara", "doará", "doava", "dobra", "dobre", "dobro", "dobrá", "docas", "doeis", "doemo", "doera", "doerá", "dogma", "doida", "doido", "domai", "domam", "domar", "domas", "domei", "domem", "domes", "domou", "donas", "donde", "donos", "dopai", "dopam", "dopar", "dopas", "dopei", "dopem", "dopes", "dopou", "dores", "dorme", "dormi", "dorso", "dosai", "dosam", "dosar", "dosas", "dosei", "dosem", "doses", "dosou", "dotai", "dotam", "dotar", "dotas", "dotei", "dotem", "dotes", "dotou", "doura", "doure", "douro", "dourá", "douta", "douto", "doíam", "doías", "doída", "doído", "draga", "drago", "dragá", "drama", "drena", "drene", "dreno", "drená", "droga", "drogo", "drogá", "duais", "dubla", "duble", "dublo", "dublá", "ducha", "duela", "duele", "duelo", "duelá", "dueto", "dumas", "dunas", "dunga", "dupla", "duplo", "duque", "durai", "duram", "durar", "duras", "durei", "durem", "dures", "durma", "durmo", "duros", "durou", "dutos", "dália", "débil", "dólar", "dúbia", "dúbio", "dúzia", "ecoai", "ecoam", "ecoar", "ecoas", "ecoei", "ecoem", "ecoes", "ecoou", "edema", "edita", "edite", "edito", "editá", "educa", "educo", "educá", "egito", "eiras", "eixos", "ejeta", "ejete", "ejeto", "ejetá", "elege", "elegi", "elegê", "eleja", "elejo", "eleva", "eleve", "elevo", "elevá", "elite", "elixa", "elixe", "elixi", "elixo", "elmos", "emana", "emane", "emano", "emaná", "emita", "emite", "emiti", "emito", "emula", "emule", "emulo", "emulá", "encha", "enche", "enchi", "encho", "enchê", "enfia", "enfie", "enfim", "enfio", "enfiá", "enjoa", "enjoe", "enjoá", "enjôo", "enoja", "enoje", "enojo", "enojá", "entes", "entoa", "entoe", "entoá", "entra", "entre", "entro", "entrá", "então", "entôo", "envia", "envie", "envio", "enviá", "ereta", "ereto", "ergam", "ergas", "ergue", "ergui", "erguê", "erice", "erigi", "erija", "erijo", "eriça", "eriço", "eriçá", "ermos", "eroda", "erode", "erodi", "erodo", "errai", "erram", "errar", "erras", "errei", "errem", "erres", "erros", "errou", "ervas", "eríge", "escoa", "escoe", "escol", "escoá", "escôo", "espia", "espie", "espio", "espiá", "espiã", "esqui", "essas", "esses", "estai", "estar", "estas", "estes", "estio", "estou", "estás", "estão", "esvai", "esvaí", "etano", "etapa", "eteno", "etilo", "etnia", "etípe", "evada", "evade", "evadi", "evado", "evita", "evite", "evito", "evitá", "evoca", "evoco", "evocá", "exala", "exale", "exalo", "exalá", "exame", "exara", "exare", "exaro", "exará", "exata", "exato", "exiba", "exibe", "exibi", "exibo", "exige", "exigi", "exija", "exijo", "exila", "exile", "exilo", "exilá", "exima", "exime", "eximi", "eximo", "expia", "expie", "expio", "expiá", "expor", "expus", "expôs", "expõe", "extra", "exuma", "exume", "exumo", "exumá", "facas", "faces", "facho", "facão", "fadas", "fados", "faina", "faixa", "falai", "falam", "falar", "falas", "falda", "falei", "falem", "fales", "falha", "falhe", "falho", "falhá", "falia", "falir", "falis", "faliu", "falou", "falsa", "falso", "falta", "falte", "falto", "faltá", "famas", "farda", "fardo", "farei", "faria", "farol", "faros", "farpa", "farra", "farsa", "farta", "farte", "farto", "fartá", "farás", "farão", "fases", "fatal", "fatia", "fatie", "fatio", "fatiá", "fator", "fatos", "fauna", "fauno", "favas", "favor", "favos", "fazei", "fazem", "fazer", "fazes", "fazia", "façam", "faças", "febre", "fecal", "fecha", "feche", "fecho", "fechá", "fedam", "fedas", "fedei", "fedem", "feder", "fedes", "fedeu", "fedia", "fedor", "feias", "feios", "feira", "feita", "feito", "feixe", "feliz", "fenda", "fende", "fendi", "fendo", "fendê", "feras", "feraz", "ferem", "feres", "feria", "ferir", "feris", "feriu", "feroz", "ferra", "ferre", "ferro", "ferrá", "ferva", "ferve", "fervi", "fervo", "fervê", "festa", "fetal", "fetos", "feudo", "fezes", "fiado", "fiais", "fiamo", "fiapo", "fiara", "fiará", "fiava", "fibra", "ficai", "ficam", "ficar", "ficas", "ficha", "fiche", "ficho", "fichá", "ficou", "fieis", "fiemo", "figas", "figos", "filai", "filam", "filar", "filas", "filei", "filem", "files", "filha", "filho", "filia", "filie", "filio", "filiá", "filma", "filme", "filmo", "filmá", "filou", "filão", "final", "finas", "finca", "finco", "fincá", "finda", "finde", "findo", "findá", "finge", "fingi", "finja", "finjo", "finos", "finta", "finte", "finto", "fintá", "fique", "firam", "firas", "firma", "firme", "firmo", "firmá", "fisco", "fisga", "fisgo", "fisgá", "fitai", "fitam", "fitar", "fitas", "fitei", "fitem", "fites", "fitou", "fixai", "fixam", "fixar", "fixas", "fixei", "fixem", "fixes", "fixos", "fixou", "fizer", "fiéis", "flavo", "floco", "flora", "flori", "fluam", "fluas", "fluem", "fluir", "fluis", "fluiu", "fluxo", "fluía", "fluís", "fobia", "focai", "focam", "focar", "focas", "focos", "focou", "fofas", "fofos", "fogem", "foges", "fogos", "fogão", "foice", "foles", "folga", "folgo", "folgá", "folha", "folia", "fomes", "fomos", "fones", "fonte", "foque", "foram", "foras", "forca", "force", "forem", "fores", "forja", "forje", "forjo", "forjá", "forma", "forme", "formo", "formá", "forno", "foros", "forra", "forre", "forro", "forrá", "forte", "força", "forço", "forçá", "fosca", "fosco", "fossa", "fosse", "fosso", "foste", "fotos", "fraca", "fraco", "frade", "fraga", "frase", "freai", "frear", "freei", "freia", "freie", "freio", "freme", "fremi", "freou", "fresa", "frese", "freso", "fresá", "freta", "frete", "freto", "fretá", "frevo", "frias", "frigi", "frija", "frijo", "frios", "frisa", "frise", "friso", "frisá", "frita", "frite", "frito", "fritá", "frota", "fruam", "fruas", "fruem", "fruir", "fruis", "fruiu", "fruta", "fruto", "fruía", "fruís", "fríge", "fucei", "fucem", "fuces", "fugas", "fugaz", "fugia", "fugir", "fugis", "fugiu", "fujam", "fujas", "fujem", "fujes", "fujia", "fujir", "fujis", "fujiu", "fujão", "fulge", "fulgi", "fumai", "fumam", "fumar", "fumas", "fumei", "fumem", "fumes", "fumou", "funda", "funde", "fundi", "fundo", "fundá", "funga", "fungo", "fungá", "funil", "funis", "furai", "furam", "furar", "furas", "furei", "furem", "fures", "furna", "furor", "furos", "furou", "furta", "furte", "furto", "furtá", "furão", "fusco", "fusos", "fusão", "fuzil", "fuzis", "fuçai", "fuçam", "fuçar", "fuças", "fuçou", "fácil", "fátuo", "félix", "féria", "fêmea", "fêmur", "fórum", "fôrça", "fúria", "fútil", "gabai", "gabam", "gabar", "gabas", "gabei", "gabem", "gabes", "gabou", "gados", "gagas", "gagos", "gaita", "gajas", "gajos", "galas", "galga", "galgo", "galgá", "galho", "galos", "galão", "gambá", "gamos", "gamão", "ganem", "ganes", "ganha", "ganhe", "ganho", "ganhá", "gania", "ganir", "ganis", "ganiu", "ganso", "garbo", "garfa", "garfe", "garfo", "garfá", "garis", "garoa", "garoe", "garoá", "garra", "garça", "garôa", "garôo", "gases", "gasta", "gaste", "gasto", "gastá", "gatas", "gatos", "gazua", "geada", "geado", "geais", "geamo", "geara", "geará", "geava", "geeis", "geemo", "geiam", "geias", "geiem", "geies", "gelai", "gelam", "gelar", "gelas", "gelei", "gelem", "geles", "gelos", "gelou", "gemam", "gemas", "gemei", "gemem", "gemer", "gemes", "gemeu", "gemia", "genes", "genro", "gente", "gerai", "geral", "geram", "gerar", "geras", "gerei", "gerem", "geres", "geria", "gerir", "geris", "geriu", "germe", "gerou", "gesso", "gesta", "gesto", "gibão", "ginga", "gingo", "gingá", "girai", "giram", "girar", "giras", "girei", "girem", "gires", "giros", "girou", "gleba", "globo", "glosa", "glose", "gloso", "glosá", "gnomo", "goela", "goiás", "golas", "goles", "goleá", "golfo", "golpe", "gomas", "gomes", "gomos", "gongo", "gonzo", "gorai", "goram", "gorar", "goras", "gorda", "gordo", "gorei", "gorem", "gores", "gorou", "gorro", "gosma", "gosta", "goste", "gosto", "gostá", "gotas", "gozai", "gozam", "gozar", "gozas", "gozei", "gozem", "gozes", "gozos", "gozou", "grade", "grafa", "grafe", "grafo", "grafá", "grama", "grana", "grata", "grato", "graus", "grava", "grave", "gravo", "gravá", "graxa", "graxo", "graça", "grega", "grego", "greve", "grifa", "grife", "grifo", "grifá", "grila", "grile", "grilo", "grilá", "gripe", "grita", "grite", "grito", "gritá", "gruda", "grude", "grudo", "grudá", "grupo", "gruta", "grãos", "gueto", "guiai", "guiam", "guiar", "guias", "guiei", "guiem", "guies", "guiou", "guisa", "guizo", "gumes", "guria", "guris", "gália", "gêmea", "gêmeo", "gênio", "gíria", "gôdos", "hajam", "hajas", "halos", "haras", "harpa", "harém", "haste", "haure", "hauri", "havei", "haver", "havia", "heras", "herda", "herde", "herdo", "herdá", "herói", "hiato", "hiena", "hindu", "hinos", "homem", "honra", "honre", "honro", "honrá", "horas", "horda", "horta", "horto", "hotel", "houve", "hulha", "humor", "hunos", "hurra", "hábil", "hélio", "hífen", "hímen", "húmus", "iates", "ibero", "iceis", "icemo", "idade", "ideal", "idosa", "idoso", "idéia", "ienes", "igapó", "igual", "ilesa", "ileso", "ilhai", "ilham", "ilhar", "ilhas", "ilhei", "ilhem", "ilhes", "ilhou", "iluda", "ilude", "iludi", "iludo", "imita", "imite", "imito", "imitá", "imola", "imole", "imolo", "imolá", "impor", "impus", "impôs", "impõe", "imune", "inala", "inale", "inalo", "inalá", "inata", "inato", "incas", "incha", "inche", "incho", "inchá", "incoa", "incoe", "incoá", "incôo", "induz", "infla", "infle", "inflo", "inflá", "infra", "iniba", "inibe", "inibi", "inibo", "inova", "inove", "inovo", "inová", "insta", "inste", "insto", "instá", "inter", "intua", "intui", "intuo", "intuí", "invés", "irada", "irado", "irdes", "ireis", "iremo", "iriam", "irias", "irmos", "irmão", "irmãs", "iscas", "isola", "isole", "isolo", "isolá", "istmo", "itera", "itere", "itero", "iterá", "içada", "içado", "içais", "içamo", "içara", "içará", "içava", "jacas", "janta", "jante", "janto", "jantá", "japão", "jarda", "jarra", "jarro", "jatos", "jaula", "jazam", "jazas", "jazei", "jazem", "jazer", "jazes", "jazeu", "jazia", "jecas", "jegue", "jeito", "jejua", "jejue", "jejum", "jejuo", "jejuá", "jesus", "jinga", "joana", "jogai", "jogam", "jogar", "jogas", "jogos", "jogou", "jogue", "jorge", "jorra", "jorre", "jorro", "jorrá", "jovem", "jubas", "judas", "judeu", "judia", "judie", "judio", "judiá", "julga", "julgo", "julgá", "julho", "junco", "junho", "junta", "junte", "junto", "juntá", "jurai", "juram", "jurar", "juras", "jurei", "jurem", "jures", "juros", "jurou", "justa", "justo", "juíza", "juízo", "jóias", "labor", "lacei", "lacem", "laces", "lacra", "lacre", "lacro", "lacrá", "lados", "ladra", "ladre", "ladro", "ladrá", "lagar", "lagoa", "lagos", "laica", "laico", "lajes", "lamba", "lambe", "lambi", "lambo", "lambê", "lance", "lança", "lanço", "lançá", "lapso", "lares", "larga", "largo", "largá", "larva", "lasca", "lasco", "lascá", "laser", "latas", "latem", "lates", "latia", "latim", "latir", "latis", "latiu", "latão", "lauda", "laudo", "lavai", "lavam", "lavar", "lavas", "lavei", "lavem", "laves", "lavou", "lavra", "lavre", "lavro", "lavrá", "lazer", "laçai", "laçam", "laçar", "laças", "laços", "laçou", "leais", "lebre", "ledes", "legai", "legal", "legam", "legar", "legas", "legou", "legue", "leiam", "leias", "leiga", "leigo", "leite", "leito", "lemas", "lemes", "lemos", "lenda", "lendo", "lenga", "lenha", "lenho", "lenta", "lente", "lento", "lenço", "leoas", "lepra", "leque", "leram", "leras", "lerda", "lerdo", "lerei", "lerem", "leres", "leria", "lermo", "lerás", "lerão", "lesai", "lesam", "lesar", "lesas", "lesei", "lesem", "leses", "lesma", "lesou", "lesse", "leste", "lesão", "letra", "levai", "levam", "levar", "levas", "levei", "levem", "leves", "levou", "leões", "lhama", "liame", "libra", "liceu", "licor", "lidai", "lidam", "lidar", "lidas", "lidei", "lidem", "lides", "lidos", "lidou", "ligai", "ligam", "ligar", "ligas", "ligou", "ligue", "lilás", "limai", "limam", "limar", "limas", "limbo", "limei", "limem", "limes", "limou", "limpa", "limpe", "limpo", "limpá", "limão", "lince", "linda", "lindo", "linfa", "linha", "linho", "liras", "lisas", "lisos", "lista", "liste", "listo", "listá", "litro", "livra", "livre", "livro", "livrá", "lixai", "lixam", "lixar", "lixas", "lixei", "lixem", "lixes", "lixou", "lixão", "lição", "lobas", "lobos", "lobão", "locai", "local", "locam", "locar", "locas", "locou", "logra", "logre", "logro", "lográ", "loira", "loiro", "lojas", "lombo", "lonas", "longa", "longe", "longo", "lopes", "loque", "lorde", "lotai", "lotam", "lotar", "lotas", "lotei", "lotem", "lotes", "loteá", "lotou", "louca", "louco", "loura", "louro", "lousa", "louva", "louve", "louvo", "louvá", "louça", "louçã", "loção", "lucas", "lucra", "lucre", "lucro", "lucrá", "lugar", "lulas", "lunar", "lupas", "lusas", "lusos", "lutai", "lutam", "lutar", "lutas", "lutei", "lutem", "lutes", "lutou", "luvas", "luxos", "luzam", "luzas", "luzem", "luzes", "luzia", "luzir", "luzis", "luziu", "lábia", "lábio", "lácio", "lápis", "látex", "légua", "líder", "líeis", "lírio", "lítio", "lótus", "macas", "macho", "macia", "macio", "macro", "magia", "magma", "magna", "magno", "magoa", "magoe", "magos", "magoá", "magra", "magro", "magôo", "maias", "maior", "major", "malas", "males", "malha", "malhe", "malho", "malhá", "malta", "mamai", "mamam", "mamar", "mamas", "mamei", "mamem", "mames", "mamou", "mamãe", "mamão", "manas", "manca", "manco", "mancá", "manda", "mande", "mando", "mandá", "maneá", "manga", "manha", "manhã", "mania", "manja", "manje", "manjo", "manjá", "manos", "mansa", "manso", "manta", "manto", "mantê", "manés", "mapas", "mapeá", "marca", "marco", "marcá", "mares", "maria", "marra", "marta", "março", "marés", "masca", "masco", "mascá", "massa", "matai", "matam", "matar", "matas", "matei", "matem", "mates", "matiz", "matos", "matou", "maças", "maçom", "maços", "maçãs", "meada", "mecha", "medem", "medes", "media", "medir", "medis", "mediu", "mediá", "medos", "medra", "medre", "medro", "medrá", "meias", "meiga", "meigo", "meios", "meião", "melai", "melam", "melar", "melas", "melei", "melem", "meles", "melou", "melro", "melão", "meneá", "menir", "menor", "menos", "menta", "mente", "menti", "menus", "meras", "mercê", "merda", "meros", "mesas", "meses", "mesma", "mesmo", "metal", "metam", "metas", "metei", "metem", "meter", "metes", "meteu", "metia", "metro", "mexam", "mexas", "mexei", "mexem", "mexer", "mexes", "mexeu", "mexia", "meçam", "meças", "miado", "miais", "miamo", "miara", "miará", "miava", "micos", "micro", "mieis", "miemo", "migra", "migre", "migro", "migrá", "mijai", "mijam", "mijar", "mijas", "mijei", "mijem", "mijes", "mijou", "milha", "milho", "mimai", "mimam", "mimar", "mimas", "mimei", "mimem", "mimes", "mimos", "mimou", "minai", "minam", "minar", "minas", "minei", "minem", "mines", "minha", "minis", "minou", "minta", "minto", "miolo", "mirai", "miram", "mirar", "miras", "mirei", "mirem", "mires", "mirou", "mirra", "missa", "mista", "misto", "mitos", "mitra", "mixos", "mixto", "miúda", "miúdo", "moais", "moamo", "modas", "modem", "modos", "moeda", "moeis", "moela", "moemo", "moera", "moerá", "mofai", "mofam", "mofar", "mofas", "mofei", "mofem", "mofes", "mofou", "mogem", "moges", "mogno", "mogol", "moita", "molar", "molas", "molda", "molde", "moldo", "moldá", "moles", "molha", "molhe", "molho", "molhá", "momos", "monge", "monja", "monta", "monte", "monto", "montá", "morai", "moral", "moram", "morar", "moras", "morda", "morde", "mordi", "mordo", "mordê", "morei", "morem", "mores", "morna", "morno", "morou", "morra", "morre", "morri", "morro", "morrê", "morsa", "morse", "morta", "morte", "morto", "mosca", "moscá", "motel", "motor", "motos", "moura", "mouro", "movam", "movas", "movei", "movem", "mover", "moves", "moveu", "movia", "moças", "moços", "moção", "moíam", "moías", "moída", "moído", "mucos", "mudai", "mudam", "mudar", "mudas", "mudei", "mudem", "mudes", "mudez", "mudos", "mudou", "mugia", "mugir", "mugis", "mugiu", "muita", "muito", "mujam", "mujas", "mulas", "multa", "multe", "multi", "multo", "multá", "mundo", "munem", "munes", "munia", "munir", "munis", "muniu", "murai", "mural", "muram", "murar", "muras", "murei", "murem", "mures", "muros", "murou", "murro", "musas", "musca", "musco", "museu", "musgo", "máfia", "mágoa", "mário", "média", "médio", "mídia", "míope", "móvel", "múmia", "mútua", "mútuo", "nabla", "nabos", "nacos", "nadai", "nadam", "nadar", "nadas", "nadei", "nadem", "nades", "nadou", "nafta", "naipe", "nanai", "nanam", "nanar", "nanas", "nanei", "nanem", "nanes", "nanou", "nardo", "nariz", "narra", "narre", "narro", "narrá", "nasal", "nasce", "nasci", "nascê", "nasça", "nasço", "natal", "natas", "natos", "nauta", "naval", "naves", "navio", "nação", "negai", "negam", "negar", "negas", "negou", "negra", "negro", "negue", "negão", "nelas", "neles", "neném", "nenês", "nervo", "nesga", "nessa", "nesse", "nesta", "neste", "netas", "netos", "nevai", "nevam", "nevar", "nevas", "nevei", "nevem", "neves", "nevou", "nexos", "nicho", "ninai", "ninam", "ninar", "ninas", "ninei", "ninem", "nines", "ninfa", "ninho", "ninou", "nisso", "nisto", "nitro", "nobre", "nodal", "noite", "noiva", "noive", "noivo", "noivá", "nomes", "nomeá", "noras", "norma", "norte", "nossa", "nosso", "notai", "notam", "notar", "notas", "notei", "notem", "notes", "notou", "novas", "novos", "nozes", "noção", "nudez", "nulas", "nulos", "numas", "nunca", "nunes", "nutra", "nutre", "nutri", "nutro", "nuvem", "névoa", "nível", "nódoa", "obesa", "obeso", "obras", "obsta", "obste", "obsto", "obstá", "obter", "obtém", "obvia", "obvie", "obvio", "obviá", "ocaso", "ocupa", "ocupe", "ocupo", "ocupá", "odeia", "odeie", "odeio", "odiai", "odiar", "odiei", "odiou", "oeste", "ogiva", "oitão", "olhai", "olham", "olhar", "olhas", "olhei", "olhem", "olhes", "olhos", "olhou", "oliva", "ombro", "omega", "omita", "omite", "omiti", "omito", "ondas", "ondeá", "onera", "onere", "onero", "onerá", "ontem", "onças", "opaca", "opaco", "opala", "opera", "opere", "opero", "operá", "opina", "opine", "opino", "opiná", "opomo", "oporá", "optai", "optam", "optar", "optas", "optei", "optem", "optes", "optou", "opção", "opõem", "opões", "orado", "orais", "oramo", "orara", "orará", "orava", "orcas", "orcei", "orcem", "orces", "ordem", "oreis", "oremo", "orgem", "orges", "orgia", "orlai", "orlam", "orlar", "orlas", "orlei", "orlem", "orles", "orlou", "ornai", "ornam", "ornar", "ornas", "ornei", "ornem", "ornes", "ornou", "orçai", "orçam", "orçar", "orças", "orçou", "ossos", "ostra", "ouros", "ousai", "ousam", "ousar", "ousas", "ousei", "ousem", "ouses", "ousou", "outra", "outro", "ouvem", "ouves", "ouvia", "ouvir", "ouvis", "ouviu", "ouçam", "ouças", "ovais", "ovino", "oxalá", "oxida", "oxide", "oxido", "oxidá", "oásis", "pacto", "padre", "pagai", "pagam", "pagar", "pagas", "pagem", "pagos", "pagou", "pague", "pagão", "pagãs", "paira", "paire", "pairo", "pairá", "pajeá", "palco", "palha", "palma", "palmo", "pampa", "panca", "panda", "panos", "pança", "papai", "papam", "papar", "papas", "papei", "papel", "papem", "papes", "papos", "papou", "papão", "parai", "param", "parar", "paras", "parca", "parco", "parda", "pardo", "parei", "parem", "pares", "pareá", "paria", "parir", "paris", "pariu", "parou", "parta", "parte", "parti", "parto", "parvo", "pasma", "pasme", "pasmo", "pasmá", "passa", "passe", "passo", "passá", "pasta", "paste", "pasto", "pastá", "patas", "patim", "patos", "patuá", "paula", "paulo", "pausa", "pauta", "paute", "pauto", "pautá", "pavio", "pavor", "pavão", "pazes", "pecai", "pecam", "pecar", "pecas", "pecou", "pedal", "pedem", "pedes", "pedia", "pedir", "pedis", "pediu", "pedra", "pedro", "pegai", "pegam", "pegar", "pegas", "pegou", "pegue", "peida", "peide", "peido", "peidá", "peita", "peite", "peito", "peitá", "peixe", "pelai", "pelam", "pelar", "pelas", "pelei", "pelem", "peles", "pelos", "pelou", "penai", "penal", "penam", "penar", "penas", "penca", "penda", "pende", "pendi", "pendo", "pendê", "penei", "penem", "penes", "penou", "pensa", "pense", "penso", "pensá", "pente", "peque", "peras", "perca", "perco", "perda", "perde", "perdi", "perdê", "perna", "persa", "perto", "perua", "perus", "pesai", "pesam", "pesar", "pesas", "pesca", "pesco", "pescá", "pesei", "pesem", "peses", "pesos", "pesou", "peste", "petiz", "peçam", "peças", "peões", "piada", "piado", "piais", "piamo", "piano", "piara", "piará", "piauí", "piava", "picai", "picam", "picar", "picas", "picha", "piche", "picho", "pichá", "picos", "picou", "picão", "pieis", "piemo", "pifai", "pifam", "pifar", "pifas", "pifei", "pifem", "pifes", "pifou", "pilar", "pilha", "pilhe", "pilho", "pilhá", "pilão", "pince", "pinga", "pingo", "pingá", "pinha", "pinho", "pinos", "pinta", "pinte", "pinto", "pintá", "pinça", "pinço", "pinçá", "piora", "piore", "pioro", "piorá", "pipas", "pique", "pires", "pirão", "pisai", "pisam", "pisar", "pisas", "pisca", "pisco", "piscá", "pisei", "pisem", "pises", "pisou", "pista", "pivôs", "pixel", "pizza", "placa", "plana", "plane", "plano", "planá", "platô", "plebe", "plena", "pleno", "plota", "plote", "ploto", "plotá", "pluga", "plugo", "plugá", "pluma", "pneus", "pobre", "podai", "podam", "podar", "podas", "podei", "podem", "poder", "podes", "podia", "podou", "poema", "poeta", "polar", "polca", "polia", "polir", "polis", "poliu", "polpa", "polvo", "pomar", "pomba", "pombo", "pomos", "pompa", "poncã", "ponde", "pondo", "ponha", "ponho", "ponta", "ponte", "ponto", "porca", "porco", "porei", "porem", "pores", "poria", "poros", "porra", "porre", "porta", "porte", "porto", "portá", "porás", "porão", "porém", "posai", "posam", "posar", "posas", "posei", "posem", "poses", "posou", "pospô", "possa", "posse", "posso", "posta", "poste", "posto", "postá", "potes", "potro", "pouca", "pouco", "poupa", "poupe", "poupo", "poupá", "pousa", "pouse", "pouso", "pousá", "povoa", "povoe", "povos", "povoá", "povão", "povôo", "poças", "poços", "poção", "prado", "praga", "praia", "prata", "prato", "praxe", "prazo", "praça", "prece", "prega", "prego", "pregá", "prelo", "prema", "preme", "premi", "premo", "prepô", "presa", "preso", "preta", "preto", "previ", "prevê", "preza", "preze", "prezo", "prezá", "preço", "prima", "prime", "primo", "primá", "priva", "prive", "privo", "privá", "proas", "prole", "propô", "prosa", "prova", "prove", "provi", "provo", "prová", "provê", "prumo", "puder", "pudim", "pudor", "pulai", "pulam", "pular", "pulas", "pulei", "pulem", "pules", "pulga", "pulos", "pulou", "pulsa", "pulse", "pulso", "pulsá", "pumas", "punam", "punas", "punem", "punes", "punha", "punho", "punia", "punir", "punis", "puniu", "puras", "purga", "purgo", "purgá", "puros", "puser", "putas", "putos", "puxai", "puxam", "puxar", "puxas", "puxei", "puxem", "puxes", "puxou", "puxão", "páreo", "pátio", "pêlos", "pênis", "pódio", "pólos", "pônei", "púbis", "quais", "quase", "queda", "quede", "quedo", "quedá", "quepe", "quero", "querê", "quilo", "quina", "quipá", "quita", "quite", "quito", "quitá", "quiçá", "quota", "rabos", "racha", "rache", "racho", "rachá", "radar", "radia", "radie", "radio", "radiá", "raiai", "raiam", "raiar", "raias", "raiei", "raiem", "raies", "raios", "raiou", "raiva", "rajai", "rajam", "rajar", "rajas", "rajei", "rajem", "rajes", "rajou", "ralai", "ralam", "ralar", "ralas", "ralei", "ralem", "rales", "ralha", "ralhe", "ralho", "ralhá", "ralos", "ralou", "ramos", "rampa", "range", "rangi", "rangê", "ranja", "ranjo", "ranço", "rapai", "rapam", "rapar", "rapas", "rapaz", "rapei", "rapem", "rapes", "rapou", "rapta", "rapte", "rapto", "raptá", "rapés", "raras", "rareá", "raros", "rasas", "rasga", "rasgo", "rasgá", "rasos", "raspa", "raspe", "raspo", "raspá", "rasto", "ratas", "rateá", "ratos", "razão", "raças", "ração", "reagi", "reais", "reaja", "reajo", "reata", "reate", "reato", "reatá", "reavê", "reboa", "reboe", "reboá", "rebôo", "recai", "recaí", "receá", "recua", "recue", "recuo", "recuá", "recém", "redes", "redil", "redor", "reduz", "reege", "refaz", "refez", "refiz", "refém", "regai", "regam", "regar", "regas", "regei", "regem", "reger", "reges", "regeu", "regia", "regou", "regra", "regre", "regro", "regrá", "regue", "reina", "reine", "reino", "reiná", "rejam", "rejas", "reler", "reles", "releu", "relia", "relva", "relês", "remai", "remam", "remar", "remas", "remei", "remem", "remes", "remia", "remir", "remis", "remiu", "remoa", "remoe", "remos", "remou", "remoê", "remoí", "remói", "remôo", "renal", "renas", "renda", "rende", "rendi", "rendo", "rendê", "rente", "repor", "repus", "repôs", "repõe", "reses", "resma", "resta", "reste", "resto", "restá", "retas", "reter", "retos", "retém", "reuni", "rever", "revia", "revir", "reviu", "revés", "revês", "rezai", "rezam", "rezar", "rezas", "rezei", "rezem", "rezes", "rezou", "reúna", "reúne", "reúno", "riais", "riamo", "ribas", "ricas", "ricos", "rides", "rifai", "rifam", "rifar", "rifas", "rifei", "rifem", "rifes", "rifle", "rifou", "rigor", "rijas", "rijos", "rimai", "rimam", "rimar", "rimas", "rimei", "rimem", "rimes", "rimos", "rimou", "rindo", "ripas", "riram", "riras", "rirei", "rirem", "rires", "riria", "rirmo", "rirás", "rirão", "risca", "risco", "riscá", "risos", "risse", "riste", "ritmo", "ritos", "rival", "rixas", "roais", "roamo", "robôs", "rocas", "rocei", "rocem", "roces", "rocha", "rodai", "rodam", "rodar", "rodas", "rodei", "rodem", "rodes", "rodeá", "rodos", "rodou", "roeis", "roemo", "roera", "roerá", "rogai", "rogam", "rogar", "rogas", "rogem", "roges", "rogos", "rogou", "rogue", "rojão", "rolai", "rolam", "rolar", "rolas", "rolei", "rolem", "roles", "rolha", "rolos", "rolou", "rombo", "rompa", "rompe", "rompi", "rompo", "rompê", "romãs", "ronca", "ronco", "roncá", "ronda", "ronde", "rondo", "rondá", "roque", "rosas", "rosca", "rosna", "rosne", "rosno", "rosná", "rosto", "rotas", "roteá", "rotos", "rouba", "roube", "roubo", "roubá", "rouca", "rouco", "roupa", "roxas", "roxos", "roçai", "roçam", "roçar", "roças", "roçou", "roíam", "roías", "roída", "roído", "rubis", "rublo", "rubra", "rubro", "rudes", "ruela", "rufai", "rufam", "rufar", "rufas", "rufei", "rufem", "rufes", "rufou", "rugai", "rugam", "rugar", "rugas", "rugia", "rugir", "rugis", "rugiu", "rugou", "rugue", "ruiam", "ruias", "ruido", "ruimo", "ruins", "ruira", "ruirá", "ruiva", "ruivo", "rujam", "rujas", "rumai", "rumam", "rumar", "rumas", "rumei", "rumem", "rumes", "rumor", "rumos", "rumou", "rural", "rusga", "russa", "russo", "ruído", "ruína", "rádio", "rédea", "régia", "régio", "régua", "ríeis", "rócio", "rósea", "róseo", "saara", "sabei", "sabem", "saber", "sabes", "sabia", "sabor", "sabre", "sabão", "sacai", "sacam", "sacar", "sacas", "sacia", "sacie", "sacio", "sacis", "saciá", "sacos", "sacou", "sacra", "sacro", "sadia", "sadio", "safai", "safam", "safar", "safas", "safei", "safem", "safes", "safou", "safra", "sagas", "sagaz", "sagra", "sagre", "sagro", "sagrá", "saiam", "saias", "saiba", "saido", "sairá", "salas", "salda", "salde", "saldo", "saldá", "sales", "salga", "salgo", "salgá", "salmo", "salsa", "salta", "salte", "salto", "saltá", "salva", "salve", "salvo", "salvá", "salão", "samba", "sambe", "sambo", "sambá", "sanai", "sanam", "sanar", "sanas", "sanei", "sanem", "sanes", "saneá", "sanha", "sanou", "santa", "santo", "sapos", "saque", "sarai", "saram", "sarar", "saras", "sarda", "sarei", "sarem", "sares", "sarna", "sarou", "sarça", "saudá", "sauna", "saxão", "saíam", "saías", "saída", "saído", "saímo", "saíra", "saúda", "saúde", "saúdo", "saúva", "seara", "sebes", "sebos", "secai", "secam", "secar", "secas", "secos", "secou", "sedas", "sedes", "sedia", "sedie", "sedio", "sediá", "seduz", "segue", "segui", "seios", "seita", "seiva", "seixo", "sejam", "sejas", "selai", "selam", "selar", "selas", "selei", "selem", "seles", "selim", "selos", "selou", "selva", "semeá", "senda", "sendo", "senha", "senos", "senso", "senta", "sente", "senti", "sento", "sentá", "senão", "seque", "serei", "serem", "seres", "seria", "serie", "serio", "seriá", "serra", "serre", "serro", "serrá", "serva", "serve", "servi", "servo", "serze", "serzi", "serás", "serão", "sesta", "setas", "setor", "sexos", "sexta", "sexto", "seção", "sifão", "sigam", "sigas", "sigla", "sigma", "signo", "silos", "silva", "silve", "silvo", "silvá", "simão", "sinal", "sinas", "sinos", "sinta", "sinto", "siris", "sirva", "sirvo", "sirza", "sirzo", "sisma", "sisme", "sismo", "sismá", "sitas", "sitia", "sitie", "sitio", "sitiá", "sitos", "situa", "situe", "situo", "situá", "soado", "soais", "soamo", "soara", "soará", "soava", "sobem", "sobes", "sobra", "sobre", "sobro", "sobrá", "socai", "socam", "socar", "socas", "socos", "socou", "soeis", "soemo", "sofra", "sofre", "sofri", "sofro", "sofrê", "sofás", "sogra", "sogro", "solai", "solam", "solar", "solas", "solda", "solde", "soldo", "soldá", "solei", "solem", "soles", "solos", "solou", "solta", "solte", "solto", "soltá", "somai", "somam", "somar", "somas", "somei", "somem", "somes", "somos", "somou", "sonda", "sonde", "sondo", "sondá", "sonha", "sonhe", "sonho", "sonhá", "sonos", "sonsa", "sonso", "sopas", "sopra", "sopre", "sopro", "soprá", "sopés", "soque", "soros", "sorri", "sorta", "sorte", "sorti", "sorva", "sorve", "sorvi", "sorvo", "sorvê", "soube", "sousa", "souza", "sovai", "sovam", "sovar", "sovas", "sovei", "sovem", "soves", "sovou", "suada", "suado", "suais", "suamo", "suara", "suará", "suava", "suave", "subam", "subas", "subia", "subir", "subis", "subiu", "sucos", "sudão", "sueca", "sueco", "sueis", "suemo", "sugai", "sugam", "sugar", "sugas", "sugou", "sugue", "sujai", "sujam", "sujar", "sujas", "sujei", "sujem", "sujes", "sujos", "sujou", "sulca", "sulco", "sulcá", "sulfa", "sumam", "sumas", "sumia", "sumir", "sumis", "sumiu", "sunga", "super", "supor", "supra", "supre", "supri", "supro", "supus", "supôs", "supõe", "surda", "surdo", "surge", "surgi", "surja", "surjo", "surra", "surre", "surro", "surrá", "surta", "surte", "surto", "susta", "suste", "susti", "susto", "sustá", "sustê", "sutil", "sutis", "sutiã", "suína", "suíno", "suíça", "suíço", "sábia", "sábio", "sépia", "séria", "série", "sério", "sêmen", "sílex", "símio", "síria", "sírio", "sítio", "sócia", "sócio", "sódio", "sósia", "sótão", "tabas", "tacai", "tacam", "tacar", "tacas", "tacha", "tache", "tacho", "tachá", "tacos", "tacou", "taipa", "talas", "talco", "talha", "talhe", "talho", "talhá", "talos", "talão", "tampa", "tampe", "tampo", "tampá", "tanga", "tange", "tangi", "tango", "tangê", "tanja", "tanjo", "tanta", "tanto", "tantã", "tapai", "tapam", "tapar", "tapas", "tapei", "tapem", "tapes", "tapeá", "tapou", "tapão", "taque", "taras", "tarda", "tarde", "tardo", "tardá", "tarja", "tateá", "tatua", "tatue", "tatuo", "tatus", "tatuá", "taxai", "taxam", "taxar", "taxas", "taxei", "taxem", "taxes", "taxou", "taças", "tecei", "tecem", "tecer", "teces", "teceu", "tecia", "tecla", "tecle", "teclo", "teclá", "teias", "teima", "teime", "teimo", "teimá", "telas", "teles", "telha", "telão", "temam", "temas", "temei", "temem", "temer", "temes", "temeu", "temia", "temor", "temos", "tempo", "tenaz", "tenda", "tende", "tendi", "tendo", "tendê", "tenha", "tenho", "tenor", "tenra", "tenro", "tensa", "tenso", "tenta", "tente", "tento", "tentá", "terei", "terem", "teres", "teria", "termo", "terna", "terno", "terra", "terás", "terão", "terça", "terço", "tesas", "teses", "tesos", "testa", "teste", "testo", "testá", "tesão", "tetas", "tetos", "texto", "teçam", "teças", "tiara", "tidas", "tidos", "tietê", "tigre", "times", "timão", "tinam", "tinas", "tinem", "tines", "tingi", "tinha", "tinia", "tinir", "tinis", "tiniu", "tinja", "tinjo", "tinta", "tinto", "tipos", "tirai", "tiram", "tirar", "tiras", "tirei", "tirem", "tires", "tiros", "tirou", "titia", "titio", "titãs", "tiver", "tição", "toada", "tocai", "tocam", "tocar", "tocas", "tocha", "tocou", "todas", "todos", "togas", "tolas", "toldo", "tolha", "tolhe", "tolhi", "tolho", "tolhê", "tolos", "tomai", "tomam", "tomar", "tomas", "tomba", "tombe", "tombo", "tombá", "tomei", "tomem", "tomes", "tomou", "tomás", "tonel", "tonta", "tonto", "topai", "topam", "topar", "topas", "topei", "topem", "topes", "topos", "topou", "toque", "toras", "torce", "torci", "torcê", "torna", "torne", "torno", "torná", "toros", "torpe", "torra", "torre", "torro", "torrá", "torta", "torto", "torça", "torço", "tosai", "tosam", "tosar", "tosas", "tosca", "tosco", "tosei", "tosem", "toses", "tosou", "tosse", "tossi", "tosta", "toste", "tosto", "tostá", "total", "totem", "touca", "touro", "trace", "traem", "traga", "trago", "tragá", "traia", "traio", "trair", "trais", "traiu", "traja", "traje", "trajo", "trajá", "trama", "trapo", "trará", "trata", "trate", "trato", "tratá", "trava", "trave", "travo", "travá", "traze", "trazê", "traça", "traço", "traçá", "traía", "traís", "treco", "trema", "treme", "tremi", "tremo", "tremê", "trena", "trens", "trenó", "trepa", "trepe", "trepo", "trepá", "treta", "treva", "trevo", "treze", "tribo", "tricô", "trigo", "trina", "trino", "trios", "tripa", "troca", "troce", "troco", "trocá", "trono", "tropa", "trota", "trote", "troto", "trotá", "trova", "troça", "troço", "troçá", "truco", "trufa", "truta", "tróia", "tubos", "tufão", "tumba", "tumor", "tupis", "turba", "turbe", "turbo", "turbá", "turca", "turco", "turma", "turno", "turnê", "turva", "turve", "turvo", "turvá", "tussa", "tusso", "tutor", "tábua", "táxis", "tédio", "tênis", "tênue", "tíbia", "tíbio", "tínge", "tórax", "tório", "túnel", "ufana", "ufane", "ufano", "ufaná", "uivai", "uivam", "uivar", "uivas", "uivei", "uivem", "uives", "uivos", "uivou", "ultra", "ulula", "ulule", "ululo", "ululá", "unais", "unemo", "ungem", "unges", "ungia", "ungir", "ungis", "ungiu", "unhas", "uniam", "unias", "unida", "unido", "unimo", "unira", "unirá", "união", "untai", "untam", "untar", "untas", "untei", "untem", "untes", "untou", "unção", "urano", "urdam", "urdas", "urdem", "urdes", "urdia", "urdir", "urdis", "urdiu", "urgia", "urgir", "urgis", "urgiu", "urina", "urine", "urino", "uriná", "urjam", "urjas", "urnas", "urrai", "urram", "urrar", "urras", "urrei", "urrem", "urres", "urros", "urrou", "ursas", "ursos", "urubu", "uréia", "usada", "usado", "usais", "usamo", "usara", "usará", "usava", "useis", "usemo", "usina", "usual", "usura", "vacas", "vades", "vadeá", "vadia", "vadie", "vadio", "vadiá", "vagai", "vagam", "vagar", "vagas", "vagem", "vagia", "vagir", "vagis", "vagiu", "vagos", "vagou", "vague", "vagão", "vaiai", "vaiam", "vaiar", "vaias", "vaiei", "vaiem", "vaies", "vaiou", "valas", "valei", "valem", "valer", "vales", "valeu", "valha", "valho", "valia", "valor", "valos", "valsa", "vamos", "vapor", "varai", "varam", "varar", "varas", "varei", "varem", "vares", "varia", "varie", "vario", "variá", "varou", "varra", "varre", "varri", "varro", "varrê", "varão", "vasos", "vasta", "vasto", "vazai", "vazam", "vazar", "vazas", "vazei", "vazem", "vazes", "vazia", "vazio", "vazou", "vazão", "veado", "vedai", "vedam", "vedar", "vedas", "vedei", "vedem", "vedes", "vedou", "veias", "vejai", "vejam", "vejas", "velai", "velam", "velar", "velas", "velei", "velem", "veles", "velha", "velho", "velou", "veloz", "vemos", "venal", "vence", "venci", "vencê", "venda", "vende", "vendi", "vendo", "vendá", "vendê", "venha", "venho", "venta", "vente", "vento", "ventá", "vença", "venço", "verba", "verbo", "verde", "verei", "verem", "veres", "verga", "veria", "verme", "versa", "verse", "verso", "versá", "verta", "verte", "verti", "verto", "vertê", "verás", "verão", "vesga", "vesgo", "vespa", "veste", "vesti", "vetai", "vetam", "vetar", "vetas", "vetei", "vetem", "vetes", "vetor", "vetou", "vexai", "vexam", "vexar", "vexas", "vexei", "vexem", "vexes", "vexou", "vezes", "viaja", "viaje", "viajo", "viajá", "viana", "vibra", "vibre", "vibro", "vibrá", "vicia", "vicie", "vicio", "viciá", "vidas", "vidra", "vidre", "vidro", "vidrá", "viela", "viena", "viera", "vieza", "vigas", "vigia", "vigie", "vigio", "vigiá", "vigor", "vilas", "vilão", "vilãs", "vimos", "vinca", "vinco", "vincá", "vinda", "vinde", "vindo", "vinga", "vingo", "vingá", "vinha", "vinho", "vinte", "viola", "viole", "violo", "violá", "virai", "viram", "virar", "viras", "virei", "virem", "vires", "viria", "viril", "viris", "virmo", "virou", "virás", "virão", "visai", "visam", "visar", "visas", "visei", "visem", "vises", "visou", "visse", "vista", "viste", "visto", "visão", "vital", "viuva", "viuve", "viuvo", "viuvá", "vivam", "vivas", "vivaz", "vivei", "vivem", "viver", "vives", "viveu", "vivia", "vivos", "viões", "viúva", "viúvo", "voado", "voais", "voamo", "voara", "voará", "voava", "vocês", "vodca", "voeis", "voemo", "vogal", "volta", "volte", "volto", "voltá", "volva", "volve", "volvi", "volvo", "volvê", "voraz", "vossa", "vosso", "votai", "votam", "votar", "votas", "votei", "votem", "votes", "votos", "votou", "vovós", "vovôs", "vozes", "vulgo", "vulto", "vulva", "vácuo", "vária", "vênia", "vício", "vídeo", "víeis", "vírus", "vôlei", "xales", "xarás", "xelim", "xeque", "xerox", "xiita", "xinga", "xingo", "xingá", "xisto", "xucra", "xucro", "xérox", "zagas", "zanga", "zango", "zangá", "zanza", "zanze", "zanzo", "zanzá", "zarpa", "zarpe", "zarpo", "zarpá", "zebra", "zelai", "zelam", "zelar", "zelas", "zelei", "zelem", "zeles", "zelou", "zerai", "zeram", "zerar", "zeras", "zerei", "zerem", "zeres", "zeros", "zerou", "zinco", "zomba", "zombe", "zombo", "zombá", "zonas", "zonza", "zonzo", "zumba", "zumbe", "zumbi", "zumbo", "zunam", "zunas", "zunem", "zunes", "zunia", "zunir", "zunis", "zuniu", "zurra", "zurre", "zurro", "zurrá", "zíper", "Átila", "Ávila", "Édipo", "Éfeso", "Épiro", "Érica", "Érico", "Évora", "Índia", "Órion", "ábaco", "ácaro", "ácida", "ácido", "ágape", "ágata", "ágeis", "ágios", "águas", "águia", "álamo", "álbum", "álibi", "ápice", "árabe", "árdua", "árduo", "áreas", "árias", "árida", "árido", "átomo", "átona", "átono", "átrio", "áurea", "áureo", "ávida", "ávido", "ázimo", "âmago", "âmbar", "ânimo", "ânodo", "ânsia", "ébano", "ébrio", "éguas", "épica", "épico", "época", "éreis", "ésima", "ésimo", "ética", "ético", "êmula", "êmulo", "êxito", "êxodo", "íamos", "ícone", "ídolo", "ígnea", "ígneo", "ímpar", "ímpia", "ímpio", "índia", "índio", "ítalo", "ítens", "óbito", "óbolo", "óbvia", "óbvio", "ódios", "óleos", "ópera", "órfão", "órfãs", "órgão", "óssea", "ósseo", "ótica", "ótico", "ótima", "ótimo", "óvulo", "óxido", "úmida", "úmido", "única", "único", "úrico", "úteis", "útero"];

// remove os acentos e muda para maiúsculo as palavras
var guessList = removeAccentsAndLowercase(dictionary);

// combina lista de palavras aleatórias + lista de palavras alvo
guessList = guessList.concat(wordList);

// Palavra atual (será escolhida pela função pickWord)
var word = "";

// Chave usada no localStorage para armazenar palavras já acertadas no modo livre
const STORAGE_KEY = 'modolivre_completed';

// Marca a palavra atual como completada (apenas quando o jogador vencer)
function markWordCompleted() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY) || '[]';
        const completed = JSON.parse(raw);
        // normaliza (sem acentos, lowercase)
        const normalized = word.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, '');
        if (!completed.includes(normalized)) {
            completed.push(normalized);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(completed));
        }
    } catch (e) {
        console.error('Erro ao marcar palavra completada:', e);
    }
}

// Escolhe uma palavra aleatória que ainda não foi acertada; quando todas
// já tiverem sido acertadas, reinicia a lista (assim as palavras só
// repetem depois de todas terem sido completadas)
function pickWord() {
    // lista normalizada (sem acentos, lowercase) para comparações
    const normalizedList = removeAccentsAndLowercase(wordList);

    let completed = [];
    try {
        completed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    } catch (e) {
        completed = [];
    }

    // cria lista de disponíveis filtrando as completadas
    let available = normalizedList.filter(w => !completed.includes(w));

    // se não há disponíveis, reinicia completadas (permitindo repetir)
    if (available.length === 0) {
        completed = [];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(completed));
        available = normalizedList.slice();
    }

    // escolhe uma aleatória da lista disponível
    const chosenNormalized = available[Math.floor(Math.random() * available.length)];

    // encontra o índice original e define a palavra com uppercase
    const idx = normalizedList.indexOf(chosenNormalized);
    if (idx >= 0) {
        word = wordList[idx].toUpperCase();
    } else {
        // fallback simples
        word = wordList[Math.floor(Math.random() * wordList.length)].toUpperCase();
    }

    console.log("Palavra escolhida (modo livre):", word);
}

// Função que roda depois que todo o HTML foi carregado
window.onload = function()
{
    // escolhe a palavra para este round (respeita palavras já acertadas)
    pickWord();

    // pega o caminho do gif
    const gifPath = `gifs/${word.toLowerCase()}.gif`;

    // coloca ele no html
    const gifElement = document.getElementById("gif");
    gifElement.src = gifPath;

    /*

    // Função de Fallback para caso não encontra o gif
    gifElement.onerror = function() {
        // colocar algo para indicar que ocorreu um problema e a palavra do dia nao teve um gif
        //this.src = "gifs/fallback.gif";
    };

    */

    intialize();
}
// Função que inicializa o jogo
function intialize() 
{
    // cria o tabuleiro do jogo
    for (let r = 0; r < height; r++) 
    {
        let boxTile = document.createElement("div");
        boxTile.id = "linha-" + r;
        boxTile.classList.add("row-title");

        for (let c = 0; c < width; c++) 
        {
            // <span id="0-0" class="tile">P</span>
            let tile = document.createElement("span");
            tile.id = r.toString() + "-" + c.toString();
            tile.classList.add("tile");
            tile.innerText = "";

            boxTile.appendChild(tile);
        }        
        
        document.getElementById("board").appendChild(boxTile);
    }

    // cria o teclado virtual
    let keyboard = [
        ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
        ["A", "S", "D", "F", "G", "H", "J", "K", "L", "↵"],
        ["Enter", "Z", "X", "C", "V", "B", "N", "M", "⌫" ]
    ]

    for (let i = 0; i < keyboard.length; i++) 
    {
        let currRow = keyboard[i];
        let keyboardRow = document.createElement("div");
        keyboardRow.classList.add("keyboard-row");

        for (let j = 0; j < currRow.length; j++) 
        {
            let keyTile = document.createElement("div");

            let key = currRow[j];
            keyTile.innerText = key;

            if (key == "Enter" || key == "↵" ) {
                keyTile.id = "Enter";
            }
            else if (key == "⌫") {
                keyTile.id = "Backspace";
            }
            else if ("A" <= key && key <= "Z") {
                keyTile.id = "Key" + key; // "Key" + "A";
            } 

            keyTile.addEventListener("click", processKey);

            if (key == "Enter") {
                keyTile.classList.add("enter-key-tile");
            } 
            else if (key == "↵") {
                keyTile.classList.add("altenter-key-tile");
            }   
            else {
                keyTile.classList.add("key-tile");
            }

            keyboardRow.appendChild(keyTile);
        }
        document.body.appendChild(keyboardRow);
    }
    
    // escuta eventos do teclado físico
    document.addEventListener("keyup", (e) => {
        processInput(e);
    })
}


// Função chamada ao clicar nas teclas virtuais
function processKey() 
{
    e = { "code" : this.id };
    processInput(e);
}

// Funçao que processa entradas do usuário (teclado físico/virtual)
function processInput(e) 
{
    if (gameOver) return; 

    // digitação de letras
    if ("KeyA" <= e.code && e.code <= "KeyZ") 
    {
        if (col < width) 
        {
            let currTile = document.getElementById(row.toString() + '-' + col.toString());

            if (currTile.innerText == "") 
            {
                currTile.innerText = e.code[3]; // pega a letra digitada

                // coloca a animação quando uma letra é digitada
                currTile.classList.remove("animate-letter"); // reinicia a animação
                void currTile.offsetWidth;                   // força reflow para reiniciar a animação
                currTile.classList.add("animate-letter");    // aplica a animação

                col += 1;
            }
        }
    }
    // backspace para apagar a letra anterior
    else if (e.code == "Backspace") 
    {
        if (0 < col && col <= width) {
            col -=1;
        }

        let currTile = document.getElementById(row.toString() + '-' + col.toString());

        // coloca animação quando a letra é removida
        currTile.classList.remove("animate-letter"); // reinicia a animação
        void currTile.offsetWidth;                   // força reflow para reiniciar a animação
        currTile.classList.add("animate-letter");    // aplica a animação

        currTile.innerText = "";
    }
    // enter para submeter a tentativa
    else if (e.code == "Enter" || e.code == "↵") {
        update();
    }

    // se chegar no limite de tentativas e não acertar, mostra a palavra
    if (!gameOver && row == height) 
    {
        gameOver = true;
        playerWin = false;
    }

    // chama o popup de derrota
    if (gameOver) {
        open();
    }
}

// Função principal que verifica a tentativa atual
function update() 
{
    let guess = "";
    document.getElementById("answer").innerText = "";

    // monta a palavra digitada a partir do tabuleiro
    for (let c = 0; c < width; c++) 
    {
        let currTile = document.getElementById(row.toString() + '-' + c.toString());
        let letter = currTile.innerText;
        guess += letter;
    }

    guess = guess.toLowerCase(); // ignora maiúsculas/minúsculas
    console.log(guess);

    // verifica se a palavra está na lista
    if (!guessList.includes(guess)) 
    {
        // animação para quando a palavra não existe no guessList
        let currRow = document.getElementById("linha-" + row);

        currRow.classList.remove("animate-invalid-row");
        void currRow.offsetWidth;
        currRow.classList.add("animate-invalid-row");

        return;
    }




    

    // verifica se a tentativa ja foi tentada anteriormente
    for (let i = 0; i < guessArr.length; i++)
    {
        // se a tentiva atual for igual a tentativa que ja foi
        if (guess === guessArr[i]) 
        {
            // entao impede ela de ser tentada novamente
            let currRow = document.getElementById("linha-" + row);

            currRow.classList.remove("animate-invalid-row");
            void currRow.offsetWidth;
            currRow.classList.add("animate-invalid-row");

            return;
        }
    }

    // acrescenta os elementos no final do array
    guessArr.push(guess);
    console.log(guessArr);

    



    // animação pra quando a palavra existe no guessList
    let currRow = document.getElementById("linha-" + row);
    
    currRow.classList.remove("animate-valid-row");
    void currRow.offsetWidth;
    currRow.classList.add("animate-valid-row");
    
    // processa tentativa
    let correct = 0;

    // cria um objeto para contar a quantidade de cada letra na palavra
    let letterCount = {}; 

    for (let i = 0; i < word.length; i++) 
    {
        let letter = word[i];

        if (letterCount[letter]) {
           letterCount[letter] += 1;
        } 
        else {
           letterCount[letter] = 1;
        }
    }

    console.log(letterCount);

    // verifica acertos na posição correta
    for (let c = 0; c < width; c++) 
    {
        let currTile = document.getElementById(row.toString() + '-' + c.toString());
        let letter = currTile.innerText;

        if (word[c] == letter) 
        {
            currTile.classList.add("correct"); // letra correta

            let keyTile = document.getElementById("Key" + letter);
            keyTile.classList.remove("present");
            keyTile.classList.add("correct");

            correct += 1;
            letterCount[letter] -= 1; // decrementa contagem da letra
        }

        // Se acertou todas as letras, então jogo acaba
        if (correct == width) {
            gameOver = true;
            playerWin = true;
        }
    }

    console.log(letterCount);

    // verifica letras presentes mas em posição errada
    for (let c = 0; c < width; c++) 
    {
        let currTile = document.getElementById(row.toString() + '-' + c.toString());
        let letter = currTile.innerText;

        if (!currTile.classList.contains("correct")) 
        {
            if (word.includes(letter) && letterCount[letter] > 0) 
            {
                currTile.classList.add("present"); // letra está presente na palavra
                
                let keyTile = document.getElementById("Key" + letter);

                if (!keyTile.classList.contains("correct")) {
                    keyTile.classList.add("present");
                }

                letterCount[letter] -= 1;
            } 
            else 
            {
                currTile.classList.add("absent"); // letra não está na palavra

                let keyTile = document.getElementById("Key" + letter);
                keyTile.classList.add("absent")
            }
        }
    }

    // próxima linha para nova tentativa
    row += 1;
    col = 0; 

    // chama o popup de vitória
    if (gameOver) {
        open();
    }
}

function open()
{
    if (playerWin) {
        // marca a palavra como completada para evitar repetições futuras
        try { markWordCompleted(); } catch(e) { console.error(e); }

        document.getElementById('popupVictory').style.display = 'block';
        document.getElementById('popup-answer-victory').innerText = word;
    } else {
        document.getElementById('popupDefeat').style.display = 'block';
        document.getElementById('popup-answer-defeat').innerText = word;
    }
}

function closePopup(id)
{
    if (id) {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
        return;
    }
    document.getElementById('popupVictory').style.display = 'none';
    document.getElementById('popupDefeat').style.display = 'none';
}

// Função para iniciar uma nova palavra
function nextWord() {
    // Limpa o tabuleiro
    for (let r = 0; r < height; r++) {
        for (let c = 0; c < width; c++) {
            let tile = document.getElementById(r.toString() + "-" + c.toString());
            tile.innerText = "";
            tile.classList.remove("correct", "present", "absent", "animate-letter");
        }
    }

    // Limpa o teclado virtual
    for (let i = 65; i <= 90; i++) {
        let key = String.fromCharCode(i);
        let keyTile = document.getElementById("Key" + key);
        if (keyTile) {
            keyTile.classList.remove("correct", "present", "absent");
        }
    }

    // Reseta as variáveis do jogo
    row = 0;
    col = 0;
    gameOver = false;
    playerWin = false;
    guessArr = [];

    // Escolhe uma nova palavra
    pickWord();

    // Atualiza o GIF
    const gifPath = `gifs/${word.toLowerCase()}.gif`;
    const gifElement = document.getElementById("gif");
    gifElement.src = gifPath;

    // Fecha os popups
    closePopup();
}
