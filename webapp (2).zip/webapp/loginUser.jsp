<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>DayLibras - Login</title>
		<link rel="stylesheet" href="css/styles.css">

		<style>
			.alert {
				background-color: #f8d7da;
				color: #721c24;
				border: 1px solid #f5c6cb;
				padding: 10px;
				border-radius: 6px;
				margin-top: 15px;
				text-align: center;
				font-size: 14px;
			}
			
			.input-group {
				position: relative;
				display: flex;
				align-items: center;
				margin-bottom: 10px;
			}
			
			.input-group input {
				width: 100%;
				padding-right: 35px;
				box-sizing: border-box;
			}
			
			.toggle-senha {
				position: absolute;
				right: 10px;
				cursor: pointer;
				user-select: none;
				font-size: 16px;
			}
		</style>
	</head>

	<body>
		<div class="container">
			<header>
				<div class="menu">
					<img src="img/menu.png" width="40px">
				</div>
				<a href="index.jsp"> <img src="img/logo.png"> </a>
				<div class="moon">
					<img src="img/darkmode.png" width="40px" onclick="toggleDarkMode()">
				</div>
			</header>
	
			<div class="box">
				<img src="img/login.png" width="110px">
				<form action="loginServlet" method="post">
					<div class="input-group">
						<input type="email" name="email" id="email"
							placeholder="email@exemplo.com" required>
					</div>
	
					<div class="input-group">
						<input type="password" name="senha" id="senha" placeholder="*********" required>
						<img class="toggle-senha" onclick="toggleSenha()" src="img/register/versenha.png" width="20px">
					</div>

					<button type="submit" class="btn-acessar">Login</button>
					<button type="button" class="btn-cadastro" onclick="irCadastro()">Novo Cadastro</button>
				</form>
	
				<%
				Object result = request.getAttribute("result");
				if (result != null && "loginError".equals(result.toString())) {
				%>
				<div class="alert" id="alert-box"
					style="background: #0000000; color: #a94442; padding: 10px; border: 1px solid #a94442; border-radius: 5px; position: relative;">
					Email ou senha inválidos. Tente novamente.
					<button onclick="fecharAlerta()" style="position: absolute; right: 8px; top: -14px; background: none; color: #00000; border: none; font-size: 16px; cursor: pointer; color: #a94442;"">✖</button>
				</div>
				<%
				}
				%>
			</div>
		</div>
	
		<script>
			// Redireciona para cadastro.html
			function irCadastro() {
			  window.location.href = "cadastro.html";
			}
		
			// Redireciona para perfil.html
			function irPerfil(event) {
			  if(event) event.preventDefault(); // evita reload no submit
			  window.location.href = "perfil.html";
			}
		
			// Voltar para a página anterior ou ajustar o link
			function voltarMenu() {
			  window.history.back();
			  // ou para sempre ir para login: window.location.href = "login.html";
			}
	
			function irCadastro() {
				window.location.href = "registerUser.jsp";
			}

			function fecharAlerta() {
				document.getElementById("alert-box").style.display = "none";
			}

			function toggleSenha() {
				const input = document.getElementById("senha");
				input.type = (input.type === "password") ? "text" : "password";
			}
		
			// =================== modo escuro ===================
			function toggleDarkMode() {
			  document.body.classList.toggle("dark");
		
			  // Troca ícone do modo (lua/sol)
			  const moonImg = document.querySelector('.moon img');
			  moonImg.src = document.body.classList.contains("dark")
			    ? "img/lightmode.png"
			    : "img/darkmode.png";
		
			  // Troca cor da logo `DayLibras` (claro/escuro)
			  const logoImg = document.querySelector('header img[src*="logo"]');
			  if (logoImg) {
			    logoImg.src = document.body.classList.contains("dark")
			      ? "img/darklogo.png"
			      : "img/logo.png";
			  }
		
			  // Troca cor do menu hamburguer (claro/escuro)
			  const menuImg = document.querySelector('.menu img');
			  if (menuImg) {
			    menuImg.src = document.body.classList.contains("dark")
			      ? "img/darkmenu.png"
			      : "img/menu.png";
			  }
		
			  // Troca cor do login (claro/escuro)
			  const loginImg = document.querySelector('.box img[src*="login"]');
			  if (loginImg) {
			    loginImg.src = document.body.classList.contains("dark")
			      ? "img/darklogin.png"
			      : "img/login.png";
			  }
		
			  // sound effect ao clicar no toggle
			  const audioSrc = document.body.classList.contains("dark")
			    ? "audio/bubble-popLua.mp3"
			    : "audio/bubble-popSol.mp3";
			  const audio = new Audio(audioSrc);
			  audio.play();
			}
		</script>
	</body>
</html>



