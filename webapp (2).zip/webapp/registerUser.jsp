<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>DayLibras - Novo Cadastro</title>
		<link rel="stylesheet" href="css/styles.css">
	</head>

	<body>
		<div class="container">
			<header>
				<div class="menu">
					<img src="img/menu.png" width="40px">
				</div>
				<a href="index.jsp"> <img src="img/logo.png"> </a>
				<div class="moon">
					<img src="img/darkmode.png" width="40px">
				</div>
			</header>
	
			<div class="box">
				<img src="img/register/cadastrar.png" width="160px">
				<form action="userRegisterServlet" method="post">
					<label for="nome">Nome*</label>
					<input type="text" name="nome" id="nome" placeholder="Nome de usuário" required> 
					<label for="email">E-mail*</label>
					<input type="email" name="email" id="email" placeholder="email@exemplo.com" required>
					<label for="email">Senha*</label>
					<input type="text" name="senha" id="senha" placeholder="********" required>
					<button type="submit" class="btn-acessar">Cadastrar</button>
				</form>
			</div>
		</div>
	</body>
</html>


